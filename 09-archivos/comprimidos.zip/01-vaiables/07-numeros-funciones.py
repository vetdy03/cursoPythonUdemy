import math

print(round(1.3))
print(abs(-3))

print(math.ceil(-10)) ##lleva al num entero mas cercano
print(math.floor(2.99)) #al numero entero hacia abajo
print(math.isnan(1.2))
print(int(math.pow(10,2)))
print(math.sqrt(9))
print(math.fma(3,3,5))
print(math.modf(16))
print(math.trunc(15.17))
