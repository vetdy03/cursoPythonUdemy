x = input("")

#
#
#
#