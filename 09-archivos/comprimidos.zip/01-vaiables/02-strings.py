nom = """
hola mundo mundo dl mundo inmundo
"""
name= "vetdy03"
#print(len(nom))
#print(name[0])
#print(name[0:3])
print(name[5:])
print(name[:4])
print(name[::-1])
