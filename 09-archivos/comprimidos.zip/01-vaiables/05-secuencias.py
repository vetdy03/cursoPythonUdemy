# \\

curso = "ultima \"python\" "
print(curso)
