nombre_curso = "Ultimate python"
print(nombre_curso)