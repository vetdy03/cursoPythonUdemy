num = 2 #entero
decimal = 3.3
imagin = 2 + 2j #2i

print(1 - 3)
print(1 // 3)
print(8 % 3)
print(2 ** 3)
print(2 ** 3)

num += 5
print(num)
