nombre = "nico"
nombre2 = "nikito"
nombre_completo = f"{nombre[1]} {2 + 5}"
print(nombre_completo)
