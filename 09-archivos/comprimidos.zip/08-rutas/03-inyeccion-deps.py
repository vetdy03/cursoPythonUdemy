# import Correa

# class Perro:
#     def __init__(self, Correa):#construcctor
#         self.correa = Correa() #contructor de la clase Correa

#def init_app(bbdd, api):
    #iniciando el modulo de rutas

from pathlib import Path # from two import init as init_two

path  = Path()
paths = [p for p in path.iterdir() if p.is_dir()] #esto es asignacion de lista por comprension
    paquete = __import__()