def init(graql, **_):
    print(f"Soy modulo uno: {graql}"  )