def init(db, api, **otros):#operador de desempaquetamiento
    print(f"Soy modulo dos: {db}, {api}")