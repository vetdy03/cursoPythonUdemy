
from usuarios.impuestos.utilidades import pagar_impuestos
#import usuarios
pagar_impuestos()
print(__name__)

# print(usuarios.gestion.__name__)
# print(usuarios.impuestos.__package__)
# print(usuarios.gestion.__path__)
# print(usuarios.gestion.__file__)
