#SUBPAQUETES REPSANDO VIDEO 91 

#from usuarios.acciones import guardar # * #Nunca importar todo con *
from usuarios.acciones.utils import guardar

guardar()








# # guardar()
# def guardar():
    # print("soy app.py y estoy guardando datos...")
