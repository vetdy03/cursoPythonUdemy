def guardar_crud():
    print("Guardando en el crud.py...")
