def guardar():
    print("Guardando datos y soy un subpaquete...")

def pagarImpuestos():
    print("Pagando impuestos...")