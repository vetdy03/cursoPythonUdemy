# print("Holi")
# lista = [1, 2, 3, 4, 5]
# lista[10]  # Esto generará un IndexError porque el índice 10 no existe en la lista

try:
    n1 = int(input("Introduce un primer número: "))
except:
    print("No has introducido un número válido.")