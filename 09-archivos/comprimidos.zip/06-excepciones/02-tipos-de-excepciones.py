try:
    n1 = int(input("Introduce un primer número: "))
    adfd
except ValueError as e:
    print("Ingrese un valor que corresponda.")
except NameError as e:
    print("Ocurrio un error de nombre.")