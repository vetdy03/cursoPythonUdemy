#contador de alumnos reproonafoss con baja nota 
