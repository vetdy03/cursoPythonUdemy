def largo(text): #gato
    resultado = 0
    for char in text:
        resultado += 1
    return resultado
    
    
print("hola chanchito")
l=largo("Hola mundo")
print(l)