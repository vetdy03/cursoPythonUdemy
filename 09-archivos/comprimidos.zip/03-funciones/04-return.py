def suma(a, b):
    resultado = a + b
    return resultado   

d = suma(1, 3)
c = suma(d, 3)
print(c)