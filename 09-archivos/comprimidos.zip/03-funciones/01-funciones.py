def hola(nombre, apellido="feliz"):
    print("Hola")
    print(f"bienvenido {nombre} {apellido}")
    
    
hola("niko", "nikc")
hola("vetdy")




hola(apellido="Apellido", nombre="nom")