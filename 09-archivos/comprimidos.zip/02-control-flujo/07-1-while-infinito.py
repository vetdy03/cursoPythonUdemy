comando = ""

while True:
    comando = input("$ ")
    print(comando)
    if comando.lower() == "salir":
        break