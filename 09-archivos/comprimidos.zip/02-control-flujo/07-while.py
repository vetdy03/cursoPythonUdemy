# numero = 1

# while numero < 100:
#     print(numero)
#     numero *= 2   # 

comando = ""

while comando != "salir":
    comando = input("ingresesa")
    print(comando)