# and or not
gas = True
encendido = True
edad = 18

if not gas or encendido or edad > 17:
    print("Puerde avanzar")
    