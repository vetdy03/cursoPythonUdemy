print(bool(""))    # False
print(bool("salir"))   # True
print(bool({}))  # True
resultado = ""
res = type(resultado)
print(res)