edad = 25
mensaje = "es mayor" if edad >20 else "Es menor"
# if edad > 17:
#     mensaje = "Es mayor"
# else:
#     mensaje = "Es menor"

print(mensaje)