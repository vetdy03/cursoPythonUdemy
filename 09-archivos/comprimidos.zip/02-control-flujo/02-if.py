edad = 882

if edad > 57:
    print("PUede ver la peli con descuento")
elif edad > 17:
    print("Puedes ver la peli")
else:
    print("No puedes entra ")
    print("No estes chingando")
    
print("Listo")