
buscar = 30

for numeroIndice in range(5): #range 5 es un iterable
    print(numeroIndice)
    if numeroIndice == buscar:
        print("encontrado", buscar)
        break
else:
    print("No ncontre")

# for usuario in usuarios:
#     pass
for charr in "ultimate python":
    print(charr)
#me pare3ce algo estupido pero existe el for else en python