﻿# cursopYTHONuDEMY
##python
- como hacer un bucle
