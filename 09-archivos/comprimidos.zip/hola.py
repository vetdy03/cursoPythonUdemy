"""Module providing a function printing python version."""
print("Hola mund")
print("Hola mund " * 3)
