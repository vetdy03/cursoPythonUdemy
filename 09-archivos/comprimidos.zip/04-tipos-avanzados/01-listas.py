numeros = [1, 2, 3, 4]
for id in numeros:
    print(id)

letras = ["a", "b"]
palabras_felices=["olaf", "xd", "mundo"]
boolena = [True, False]
matriz =[[0,1], [1,0], [0,3]]
ceros = [0, 1]*10
alfanumerico = numeros + letras
rago = list(range(1,11))
chars = list("hola mundo")
print(chars)
print(rago)

print(alfanumerico)
print(ceros)
print(matriz)
print(numeros)
print(boolena)