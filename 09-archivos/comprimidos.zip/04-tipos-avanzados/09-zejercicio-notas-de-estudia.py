listaDeCompras = [["cebolla",10], #1#
                  ["carne",104],
                  ["queso",12],
                  ["pollo",90],
                  ["salsa", 20],
                  ["papa",200],
                  ["arroz",480],
                  ["azucar",350],
                  ["aceite",22],
                  ["naranja",22]
                  ]

#aplicar estudiantes notas