mascotas = ["migui", "negro", "migui","pato", "migui", "olaf", "pelusa"]
print(mascotas.count("migui"))
if "pepe" in mascotas:
    print(mascotas.index("negro")) # lo busca por ti y te dice enque posicion esta ese elemento
 
 
 
    
#metodo count: CUENTA POR TI CUANTOS VECES APAREWCE EL MISMO ELEMENTO
#QUE LE PASASTE POR PARAMETRO; SINTAXIS--> mascotas.count("migui")sdñV