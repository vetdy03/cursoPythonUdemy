mascotas = ["migui", "negro", "olaf", "pelusa"]
for index, mascota in enumerate(mascotas): #enumerate DEVUELVE TUPLAS(INDICES)
    print(index,mascota)
  
  
  
  
  
  
    
# pri, seg = [1, 2]#por cosas de la vida esto funciona pero el tamanio de [] debe ser igual al tam de las variable
# print(pri, seg)


# el resultado de esto: for mascota in enumerate(mascotas):
#     print(mascota) ES ESTO; (0, 'migui')
# (1, 'negro')
# (2, 'olaf')
# (3, 'pelusa')
# 1 2
#      TUPLAS 